#!/bin/bash

# Little Bloom Setup Script
# This script automates the initial setup of the Little Bloom application

set -e

echo "=================================================="
echo "  Little Bloom E-Commerce Platform Setup"
echo "=================================================="
echo ""

# Check prerequisites
echo "📋 Checking prerequisites..."

# Check Java
if ! command -v java &> /dev/null; then
    echo "❌ Java 17+ is not installed"
    echo "Download from: https://www.oracle.com/java/technologies/downloads/"
    exit 1
fi
echo "✅ Java installed"

# Check Maven
if ! command -v mvn &> /dev/null; then
    echo "❌ Maven is not installed"
    echo "Install: brew install maven (macOS) or apt-get install maven (Linux)"
    exit 1
fi
echo "✅ Maven installed"

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed"
    echo "Download from: https://nodejs.org/"
    exit 1
fi
echo "✅ Node.js installed"

# Check npm
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed"
    exit 1
fi
echo "✅ npm installed"

# Check PostgreSQL
if ! command -v psql &> /dev/null; then
    echo "⚠️  PostgreSQL is not installed"
    echo "Install from: https://www.postgresql.org/download/"
    echo ""
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
else
    echo "✅ PostgreSQL installed"
fi

echo ""
echo "=================================================="
echo "  Database Setup"
echo "=================================================="
echo ""

read -p "Do you want to setup the database now? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    read -p "PostgreSQL username (default: postgres): " db_user
    db_user=${db_user:-postgres}
    
    read -sp "PostgreSQL password: " db_password
    echo
    
    echo "Creating database littlebloom..."
    PGPASSWORD=$db_password psql -U $db_user -h localhost -c "CREATE DATABASE littlebloom;" 2>/dev/null || echo "⚠️  Database might already exist"
    
    echo "Loading schema..."
    PGPASSWORD=$db_password psql -U $db_user -d littlebloom -f database-schema.sql
    
    echo "✅ Database setup complete"
    echo ""
    echo "Update backend/src/main/resources/application.properties:"
    echo "  spring.datasource.username=$db_user"
    echo "  spring.datasource.password=$db_password"
fi

echo ""
echo "=================================================="
echo "  Backend Setup"
echo "=================================================="
echo ""

cd backend

echo "Installing backend dependencies..."
mvn clean install

echo "✅ Backend setup complete"
echo ""
echo "To start backend:"
echo "  cd backend"
echo "  mvn spring-boot:run"
echo ""

cd ..

echo ""
echo "=================================================="
echo "  Frontend Setup"
echo "=================================================="
echo ""

cd frontend

echo "Installing frontend dependencies..."
npm install

echo "✅ Frontend setup complete"
echo ""
echo "To start frontend:"
echo "  cd frontend"
echo "  npm start"
echo ""

cd ..

echo ""
echo "=================================================="
echo "  ✅ Setup Complete!"
echo "=================================================="
echo ""
echo "Next steps:"
echo ""
echo "1. Start PostgreSQL (if not running)"
echo ""
echo "2. Terminal 1 - Start Backend:"
echo "   cd backend"
echo "   mvn spring-boot:run"
echo ""
echo "3. Terminal 2 - Start Frontend:"
echo "   cd frontend"
echo "   npm start"
echo ""
echo "4. Open http://localhost:3000 in your browser"
echo ""
echo "5. Test the application:"
echo "   - Sign up as SELLER"
echo "   - Add some products"
echo "   - Sign up as BUYER"
echo "   - Browse and purchase products"
echo ""
echo "For detailed documentation, see README.md"
echo "For quick start guide, see QUICK_START.md"
echo ""
