# Little Bloom - E-Commerce Platform
## Complete Full-Stack Application for Baby Products

### 🎯 Overview
Little Bloom is a production-ready e-commerce platform designed for baby products with separate buyer and seller portals. The system features complete inventory management, order tracking, reviews & ratings, wishlist functionality, and real-time notifications.

---

## 📋 Table of Contents
1. [Tech Stack](#tech-stack)
2. [Project Structure](#project-structure)
3. [Database Setup](#database-setup)
4. [Backend Setup](#backend-setup)
5. [Frontend Setup](#frontend-setup)
6. [Running the Application](#running-the-application)
7. [API Documentation](#api-documentation)
8. [Features](#features)

---

## 🛠️ Tech Stack

### Backend
- **Framework**: Spring Boot 3.1.5
- **Language**: Java 17
- **Database**: PostgreSQL
- **Authentication**: JWT (JSON Web Tokens)
- **Security**: BCrypt Password Hashing
- **Build Tool**: Maven

### Frontend
- **Library**: React 18.2
- **Routing**: React Router v6
- **HTTP Client**: Axios
- **State Management**: Redux Toolkit / Context API
- **Styling**: Tailwind CSS
- **Charts**: Chart.js & react-chartjs-2

---

## 📁 Project Structure

```
little-bloom-app/
├── database-schema.sql          # PostgreSQL schema
├── backend/
│   ├── pom.xml
│   └── src/main/java/com/littlebloom/
│       ├── LittleBloomApplication.java
│       ├── controller/          # REST Controllers
│       │   ├── AuthController.java
│       │   ├── ProductController.java
│       │   ├── CartController.java
│       │   ├── OrderController.java
│       │   ├── ReviewController.java
│       │   ├── NotificationController.java
│       │   └── WishlistController.java
│       ├── service/             # Business Logic
│       │   ├── AuthService.java
│       │   ├── ProductService.java
│       │   ├── CartService.java
│       │   ├── OrderService.java
│       │   ├── ReviewService.java
│       │   └── NotificationService.java
│       ├── repository/          # JPA Repositories
│       ├── model/               # Entity Classes
│       ├── dto/                 # Data Transfer Objects
│       └── security/            # JWT & Security Config
└── frontend/
    ├── package.json
    ├── public/
    │   └── index.html
    └── src/
        ├── index.js
        ├── App.js
        ├── context/             # Context API
        │   └── AuthContext.js
        ├── services/            # API Client
        │   └── api.js
        ├── pages/               # Page Components
        ├── components/          # Reusable Components
        ├── styles/              # CSS/Tailwind
        └── utils/               # Utilities
```

---

## 🗄️ Database Setup

### Prerequisites
- PostgreSQL 12+
- psql CLI tool

### Steps

1. **Create Database**
```bash
psql -U postgres
CREATE DATABASE littlebloom;
```

2. **Run Schema**
```bash
psql -U postgres -d littlebloom -f database-schema.sql
```

3. **Verify Tables**
```bash
\dt  # List tables
```

---

## 🚀 Backend Setup

### Prerequisites
- Java 17+
- Maven 3.8+
- PostgreSQL running on localhost:5432

### Steps

1. **Configure Database Connection**
Edit `backend/src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/littlebloom
spring.datasource.username=postgres
spring.datasource.password=your_postgres_password
```

2. **Build Backend**
```bash
cd backend
mvn clean install
```

3. **Run Backend**
```bash
mvn spring-boot:run
```

Backend will start at: `http://localhost:8080`

---

## 💻 Frontend Setup

### Prerequisites
- Node.js 16+
- npm or yarn

### Steps

1. **Install Dependencies**
```bash
cd frontend
npm install
```

2. **Configure API URL**
The API URL is configured in `src/services/api.js`:
```javascript
const API_BASE_URL = 'http://localhost:8080/api';
```

3. **Start React App**
```bash
npm start
```

Frontend will open at: `http://localhost:3000`

---

## ▶️ Running the Application

### Option 1: Separate Terminals

**Terminal 1 - Backend:**
```bash
cd backend
mvn spring-boot:run
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm start
```

### Option 2: Docker (Optional)

Create `docker-compose.yml`:
```yaml
version: '3.8'
services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: littlebloom
      POSTGRES_PASSWORD: password
    ports:
      - "5432:5432"

  backend:
    build: ./backend
    ports:
      - "8080:8080"
    depends_on:
      - postgres

  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
```

Run:
```bash
docker-compose up
```

---

## 📚 API Documentation

### Authentication APIs

#### Signup
```
POST /api/auth/signup
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123",
  "role": "BUYER",
  "address": "123 Main St",
  "city": "Mumbai",
  "state": "Maharashtra",
  "postalCode": "400001",
  "phone": "9876543210"
}

Response: { token, user }
```

#### Login
```
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "password123"
}

Response: { token, user }
```

#### Get Current User
```
GET /api/auth/me
Authorization: Bearer <token>
```

### Product APIs

#### Create Product (Seller Only)
```
POST /api/products
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Baby Dress",
  "category": "Dresses",
  "description": "Soft cotton dress",
  "price": 299.99,
  "quantity": 50,
  "size": "6-12 months",
  "imageUrl": "https://...",
  "predictedDeliveryDays": 2
}
```

#### Get All Products
```
GET /api/products?page=0&size=10
```

#### Search Products
```
GET /api/products/search?search=dress&page=0&size=10
```

#### Get Product by Category
```
GET /api/products/category/Dresses?page=0&size=10
```

### Cart APIs

#### Add to Cart
```
POST /api/cart/add
Authorization: Bearer <token>

{
  "productId": 1,
  "quantity": 2
}
```

#### Get Cart
```
GET /api/cart
Authorization: Bearer <token>
```

#### Remove from Cart
```
DELETE /api/cart/remove/{productId}
Authorization: Bearer <token>
```

#### Update Cart Quantity
```
PUT /api/cart/update/{productId}?quantity=3
Authorization: Bearer <token>
```

### Order APIs

#### Create Order
```
POST /api/orders
Authorization: Bearer <token>
```

#### Get Buyer Orders
```
GET /api/orders?page=0&size=10
Authorization: Bearer <token>
```

#### Get Seller Orders
```
GET /api/orders/seller/all
Authorization: Bearer <token>
```

#### Update Order Item Status
```
PUT /api/orders/item/{itemId}/status
Authorization: Bearer <token>

{
  "status": "Shipped"  // or "Delivered"
}
```

### Review APIs

#### Create Review (After Delivery)
```
POST /api/reviews
Authorization: Bearer <token>

{
  "orderId": 1,
  "productId": 1,
  "rating": 4,
  "feedback": "Great product!"
}
```

#### Get Product Reviews
```
GET /api/reviews/product/{productId}
```

#### Get Product Average Rating
```
GET /api/reviews/product/{productId}/rating
```

### Notification APIs

#### Get All Notifications
```
GET /api/notifications
Authorization: Bearer <token>
```

#### Get Unread Notifications
```
GET /api/notifications/unread
Authorization: Bearer <token>
```

#### Mark Notification as Read
```
PUT /api/notifications/{id}/read
Authorization: Bearer <token>
```

### Wishlist APIs

#### Add to Wishlist
```
POST /api/wishlist
Authorization: Bearer <token>

{
  "productId": 1
}
```

#### Get Wishlist
```
GET /api/wishlist
Authorization: Bearer <token>
```

#### Remove from Wishlist
```
DELETE /api/wishlist/{productId}
Authorization: Bearer <token>
```

#### Check if in Wishlist
```
GET /api/wishlist/{productId}/check
Authorization: Bearer <token>
```

---

## ✨ Features

### 👤 User Management
- ✅ Signup with role selection (Buyer/Seller)
- ✅ Login with JWT authentication
- ✅ Profile management
- ✅ Address management
- ✅ Role-based access control

### 🛒 Buyer Portal
- ✅ Home page with search bar
- ✅ Product catalog browsing
- ✅ Category filtering
- ✅ Product search with auto-suggestions
- ✅ Product details with ratings
- ✅ Add to cart & wishlist
- ✅ Checkout & payment (mock)
- ✅ Order history & tracking
- ✅ Order status: Ordered → Out for Delivery → Delivered
- ✅ Reviews & ratings (post-delivery only)
- ✅ Notifications system

### 🏪 Seller Portal
- ✅ Dashboard with sales analytics
- ✅ Weekly/Monthly/Yearly sales graphs
- ✅ Product management (CRUD)
- ✅ Image upload support
- ✅ Inventory tracking
- ✅ Order management
- ✅ Order status updates (New Order → Shipped → Delivered)
- ✅ Real-time notifications
- ✅ Sales statistics
- ✅ Customer feedback

### 🔐 Security
- ✅ JWT-based authentication
- ✅ BCrypt password hashing
- ✅ Role-based authorization
- ✅ CORS configuration
- ✅ Input validation
- ✅ SQL injection prevention (JPA)

### 📊 Advanced Features
- ✅ Product rating system (average rating calculation)
- ✅ Wishlist management
- ✅ Shopping cart with quantity management
- ✅ Order tracking with real-time updates
- ✅ Notification system (Order placed, shipped, delivered, reviews)
- ✅ Pagination
- ✅ Search & filtering
- ✅ Responsive design

---

## 🧪 Testing

### Test User Accounts

**Buyer Account:**
```
Email: buyer@example.com
Password: password123
Role: BUYER
```

**Seller Account:**
```
Email: seller@example.com
Password: password123
Role: SELLER
```

### Test Workflow
1. Sign up as a seller
2. Add some products
3. Sign up as a buyer
4. Search & browse products
5. Add items to cart
6. Place an order
7. (As seller) Update order status to "Shipped" then "Delivered"
8. (As buyer) Leave a review
9. Check notifications

---

## 📦 Production Deployment

### Backend Deployment (AWS EC2)
1. Build JAR: `mvn clean package`
2. Upload to EC2
3. Run: `java -jar little-bloom-backend-1.0.0.jar`

### Frontend Deployment (AWS S3 + CloudFront)
1. Build: `npm run build`
2. Upload `build/` to S3
3. Configure CloudFront
4. Update API URL to production backend

### Database (AWS RDS)
1. Create PostgreSQL RDS instance
2. Update connection string in `application.properties`

---

## 🐛 Troubleshooting

### Backend Issues
```
Error: Cannot connect to database
Solution: Check PostgreSQL is running and credentials are correct

Error: Port 8080 already in use
Solution: Kill process: lsof -ti:8080 | xargs kill -9

Error: Maven build fails
Solution: Clear cache: mvn clean && mvn install
```

### Frontend Issues
```
Error: Cannot reach API
Solution: Check backend is running on :8080

Error: CORS error
Solution: Verify CORS is enabled in SecurityConfig.java

Error: npm install fails
Solution: Clear cache: npm cache clean --force
```

---

## 📝 Environment Variables

### Backend (.env or application.properties)
```
JWT_SECRET=your_secret_key
JWT_EXPIRATION=86400000
DATABASE_URL=jdbc:postgresql://localhost:5432/littlebloom
DATABASE_USER=postgres
DATABASE_PASSWORD=password
CORS_ORIGINS=http://localhost:3000
FILE_UPLOAD_DIR=uploads/
```

### Frontend (.env)
```
REACT_APP_API_URL=http://localhost:8080/api
```

---

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Review API documentation
3. Check backend logs
4. Check browser console for frontend errors

---

## 📄 License

This project is licensed under the MIT License.

---

## ✅ Checklist - All Features Implemented

- [x] User authentication (Signup/Login)
- [x] Role-based access control (Buyer/Seller)
- [x] Product management (CRUD)
- [x] Product search & filtering
- [x] Shopping cart
- [x] Order management
- [x] Payment integration (mock)
- [x] Order tracking
- [x] Reviews & ratings
- [x] Wishlist
- [x] Notifications
- [x] Seller dashboard with analytics
- [x] Inventory management
- [x] Real-time updates
- [x] Responsive design
- [x] Security (JWT, BCrypt, CORS)
- [x] Pagination
- [x] Image upload support
- [x] Scalable architecture

---

**Last Updated**: March 31, 2026
**Version**: 1.0.0
**Status**: Production Ready ✅
