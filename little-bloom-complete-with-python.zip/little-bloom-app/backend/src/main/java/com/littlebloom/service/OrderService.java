package com.littlebloom.service;

import com.littlebloom.dto.OrderDTO;
import com.littlebloom.dto.OrderItemDTO;
import com.littlebloom.model.*;
import com.littlebloom.repository.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    @Autowired
    private CartService cartService;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private NotificationService notificationService;

    @Transactional
    public OrderDTO createOrder(Long buyerId) {
        User buyer = userRepository.findById(buyerId)
                .orElseThrow(() -> new RuntimeException("Buyer not found"));

        Cart cart = cartRepository.findByUser(buyer)
                .orElseThrow(() -> new RuntimeException("Cart not found"));

        List<CartItem> cartItems = cartItemRepository.findByCart(cart);
        if (cartItems.isEmpty()) {
            throw new RuntimeException("Cart is empty");
        }

        BigDecimal totalPrice = BigDecimal.ZERO;

        Order order = Order.builder()
                .buyer(buyer)
                .status(Order.OrderStatus.Ordered)
                .build();

        order = orderRepository.save(order);

        for (CartItem cartItem : cartItems) {
            Product product = cartItem.getProduct();
            User seller = product.getSeller();

            // Decrement product quantity
            product.setQuantity(product.getQuantity() - cartItem.getQuantity());
            productRepository.save(product);

            BigDecimal itemPrice = product.getPrice().multiply(new BigDecimal(cartItem.getQuantity()));
            totalPrice = totalPrice.add(itemPrice);

            OrderItem orderItem = OrderItem.builder()
                    .order(order)
                    .product(product)
                    .seller(seller)
                    .quantity(cartItem.getQuantity())
                    .price(product.getPrice())
                    .status(OrderItem.OrderItemStatus.NewOrder)
                    .build();

            orderItemRepository.save(orderItem);

            // Notify seller
            notificationService.notifySellerOrderPlaced(buyer, seller, product, cartItem.getQuantity());
        }

        order.setTotalPrice(totalPrice);
        order = orderRepository.save(order);

        // Clear cart
        cartService.clearCart(buyerId);

        return getOrderDTO(order);
    }

    public Page<OrderDTO> getBuyerOrders(Long buyerId, Pageable pageable) {
        User buyer = userRepository.findById(buyerId)
                .orElseThrow(() -> new RuntimeException("Buyer not found"));

        return orderRepository.findByBuyer(buyer, pageable)
                .map(this::getOrderDTO);
    }

    public List<OrderDTO> getBuyerOrdersAll(Long buyerId) {
        User buyer = userRepository.findById(buyerId)
                .orElseThrow(() -> new RuntimeException("Buyer not found"));

        return orderRepository.findByBuyerOrderByCreatedAtDesc(buyer).stream()
                .map(this::getOrderDTO)
                .collect(Collectors.toList());
    }

    public OrderDTO getOrderById(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        return getOrderDTO(order);
    }

    @Transactional
    public void updateOrderItemStatus(Long orderItemId, String status) {
        OrderItem orderItem = orderItemRepository.findById(orderItemId)
                .orElseThrow(() -> new RuntimeException("Order item not found"));

        orderItem.setStatus(OrderItem.OrderItemStatus.valueOf(status));
        orderItemRepository.save(orderItem);

        // Check if all items are delivered, then update order status
        Order order = orderItem.getOrder();
        List<OrderItem> allItems = orderItemRepository.findByOrder(order);

        boolean allDelivered = allItems.stream()
                .allMatch(item -> item.getStatus() == OrderItem.OrderItemStatus.Delivered);

        if (allDelivered) {
            order.setStatus(Order.OrderStatus.Delivered);
            orderRepository.save(order);
            
            // Notify buyer order delivered
            notificationService.notifyBuyerOrderDelivered(order);
        } else {
            boolean anyShipped = allItems.stream()
                    .anyMatch(item -> item.getStatus() == OrderItem.OrderItemStatus.Shipped);

            if (anyShipped && order.getStatus() == Order.OrderStatus.Ordered) {
                order.setStatus(Order.OrderStatus.OutForDelivery);
                orderRepository.save(order);
                
                // Notify buyer order shipped
                notificationService.notifyBuyerOrderShipped(order);
            }
        }
    }

    public Page<OrderItemDTO> getSellerOrders(Long sellerId, Pageable pageable) {
        User seller = userRepository.findById(sellerId)
                .orElseThrow(() -> new RuntimeException("Seller not found"));

        return orderItemRepository.findBySeller(seller, pageable)
                .map(this::getOrderItemDTO);
    }

    public List<OrderItemDTO> getSellerOrdersAll(Long sellerId) {
        User seller = userRepository.findById(sellerId)
                .orElseThrow(() -> new RuntimeException("Seller not found"));

        return orderItemRepository.findBySellerOrderByCreatedAtDesc(seller).stream()
                .map(this::getOrderItemDTO)
                .collect(Collectors.toList());
    }

    private OrderDTO getOrderDTO(Order order) {
        List<OrderItem> items = orderItemRepository.findByOrder(order);
        List<OrderItemDTO> itemDTOs = items.stream()
                .map(this::getOrderItemDTO)
                .collect(Collectors.toList());

        return OrderDTO.builder()
                .id(order.getId())
                .userId(order.getBuyer().getId())
                .totalPrice(order.getTotalPrice())
                .status(order.getStatus().toString())
                .items(itemDTOs)
                .createdAt(order.getCreatedAt())
                .updatedAt(order.getUpdatedAt())
                .build();
    }

    private OrderItemDTO getOrderItemDTO(OrderItem item) {
        return OrderItemDTO.builder()
                .id(item.getId())
                .productId(item.getProduct().getId())
                .productName(item.getProduct().getName())
                .sellerId(item.getSeller().getId())
                .sellerName(item.getSeller().getName())
                .quantity(item.getQuantity())
                .price(item.getPrice())
                .status(item.getStatus().toString())
                .createdAt(item.getCreatedAt())
                .build();
    }
}
