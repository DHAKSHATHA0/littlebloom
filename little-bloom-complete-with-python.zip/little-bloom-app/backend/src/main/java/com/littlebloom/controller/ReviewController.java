package com.littlebloom.controller;

import com.littlebloom.dto.CreateReviewRequest;
import com.littlebloom.dto.ReviewDTO;
import com.littlebloom.security.CustomUserDetails;
import com.littlebloom.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reviews")
@CrossOrigin(origins = "http://localhost:3000")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    @PostMapping
    public ResponseEntity<ReviewDTO> createReview(
            Authentication authentication,
            @RequestBody CreateReviewRequest request) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        ReviewDTO review = reviewService.createReview(userDetails.getUserId(), request);
        return ResponseEntity.ok(review);
    }

    @GetMapping("/product/{productId}")
    public ResponseEntity<List<ReviewDTO>> getProductReviews(@PathVariable Long productId) {
        List<ReviewDTO> reviews = reviewService.getProductReviews(productId);
        return ResponseEntity.ok(reviews);
    }

    @GetMapping("/user")
    public ResponseEntity<List<ReviewDTO>> getUserReviews(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        List<ReviewDTO> reviews = reviewService.getUserReviews(userDetails.getUserId());
        return ResponseEntity.ok(reviews);
    }

    @GetMapping("/product/{productId}/rating")
    public ResponseEntity<Double> getProductAverageRating(@PathVariable Long productId) {
        Double rating = reviewService.getProductAverageRating(productId);
        return ResponseEntity.ok(rating);
    }

    @GetMapping("/product/{productId}/count")
    public ResponseEntity<Long> getProductReviewCount(@PathVariable Long productId) {
        Long count = reviewService.getProductReviewCount(productId);
        return ResponseEntity.ok(count);
    }
}

package com.littlebloom.controller;

import com.littlebloom.dto.NotificationDTO;
import com.littlebloom.security.CustomUserDetails;
import com.littlebloom.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notifications")
@CrossOrigin(origins = "http://localhost:3000")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @GetMapping
    public ResponseEntity<List<NotificationDTO>> getNotifications(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        List<NotificationDTO> notifications = notificationService.getUserNotifications(userDetails.getUserId());
        return ResponseEntity.ok(notifications);
    }

    @GetMapping("/unread")
    public ResponseEntity<List<NotificationDTO>> getUnreadNotifications(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        List<NotificationDTO> notifications = notificationService.getUnreadNotifications(userDetails.getUserId());
        return ResponseEntity.ok(notifications);
    }

    @PutMapping("/{id}/read")
    public ResponseEntity<Void> markAsRead(@PathVariable Long id) {
        notificationService.markNotificationAsRead(id);
        return ResponseEntity.noContent().build();
    }
}

package com.littlebloom.controller;

import com.littlebloom.dto.AddToWishlistRequest;
import com.littlebloom.dto.WishlistDTO;
import com.littlebloom.security.CustomUserDetails;
import com.littlebloom.service.WishlistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/wishlist")
@CrossOrigin(origins = "http://localhost:3000")
public class WishlistController {

    @Autowired
    private WishlistService wishlistService;

    @PostMapping
    public ResponseEntity<WishlistDTO> addToWishlist(
            Authentication authentication,
            @RequestBody AddToWishlistRequest request) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        WishlistDTO wishlist = wishlistService.addToWishlist(userDetails.getUserId(), request);
        return ResponseEntity.ok(wishlist);
    }

    @DeleteMapping("/{productId}")
    public ResponseEntity<Void> removeFromWishlist(
            Authentication authentication,
            @PathVariable Long productId) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        wishlistService.removeFromWishlist(userDetails.getUserId(), productId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<List<WishlistDTO>> getWishlist(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        List<WishlistDTO> wishlist = wishlistService.getUserWishlist(userDetails.getUserId());
        return ResponseEntity.ok(wishlist);
    }

    @GetMapping("/{productId}/check")
    public ResponseEntity<Boolean> isInWishlist(
            Authentication authentication,
            @PathVariable Long productId) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        boolean inWishlist = wishlistService.isInWishlist(userDetails.getUserId(), productId);
        return ResponseEntity.ok(inWishlist);
    }
}
