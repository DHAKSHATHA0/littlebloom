package com.littlebloom.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReviewDTO {
    private Long id;
    private Long userId;
    private String userName;
    private Long productId;
    private Long orderId;
    private Integer rating;
    private String feedback;
    private LocalDateTime createdAt;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreateReviewRequest {
    private Long orderId;
    private Long productId;
    private Integer rating;
    private String feedback;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificationDTO {
    private Long id;
    private Long senderId;
    private String senderName;
    private Long receiverId;
    private String message;
    private String type;
    private Boolean isRead;
    private LocalDateTime createdAt;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WishlistDTO {
    private Long id;
    private Long userId;
    private Long productId;
    private String productName;
    private String category;
    private String imageUrl;
    private LocalDateTime createdAt;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AddToWishlistRequest {
    private Long productId;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductAnalyticsDTO {
    private Long productId;
    private String productName;
    private Double avgRating;
    private Long reviewCount;
    private Long totalSold;
    private Long totalRevenue;
}
