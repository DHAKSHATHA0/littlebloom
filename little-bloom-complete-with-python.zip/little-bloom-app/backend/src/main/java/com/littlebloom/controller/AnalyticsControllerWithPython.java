package com.littlebloom.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import com.littlebloom.security.CustomUserDetails;
import com.littlebloom.service.OrderService;
import com.littlebloom.service.OrderService.OrderItemDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/analytics")
@CrossOrigin(origins = "http://localhost:3000")
public class AnalyticsController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private RestTemplate restTemplate;

    private static final String PYTHON_API = "http://localhost:5000/api/analytics";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Get complete dashboard analytics from Python service
     */
    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDashboard(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        try {
            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            
            // Get order data
            List<OrderItemDTO> sellerOrders = orderService.getSellerOrdersAll(userDetails.getUserId());
            
            // Prepare data for Python service
            List<Double> dailySales = sellerOrders.stream()
                    .map(order -> order.getPrice().doubleValue())
                    .collect(Collectors.toList());
            
            List<Long> dailyOrders = sellerOrders.stream()
                    .map(order -> 1L)
                    .collect(Collectors.toList());
            
            // Call Python analytics service
            Map<String, Object> request = new HashMap<>();
            request.put("daily_sales", dailySales);
            request.put("daily_orders", dailyOrders);
            request.put("period", 7);
            
            Map<String, Object> analyticsResult = restTemplate.postForObject(
                    PYTHON_API + "/dashboard",
                    request,
                    Map.class
            );
            
            return ResponseEntity.ok(analyticsResult);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(
                    Map.of("error", "Analytics service unavailable: " + e.getMessage())
            );
        }
    }

    /**
     * Linear Regression prediction
     */
    @GetMapping("/prediction/next-month")
    public ResponseEntity<Map<String, Object>> predictNextMonth(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        try {
            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            List<OrderItemDTO> sellerOrders = orderService.getSellerOrdersAll(userDetails.getUserId());
            
            List<Double> dailySales = sellerOrders.stream()
                    .map(order -> order.getPrice().doubleValue())
                    .collect(Collectors.toList());
            
            Map<String, Object> request = new HashMap<>();
            request.put("daily_sales", dailySales);
            
            Map<String, Object> prediction = restTemplate.postForObject(
                    PYTHON_API + "/predict",
                    request,
                    Map.class
            );
            
            return ResponseEntity.ok(prediction);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(
                    Map.of("error", "Prediction service unavailable: " + e.getMessage())
            );
        }
    }

    /**
     * Moving Average trend analysis
     */
    @GetMapping("/trend-analysis")
    public ResponseEntity<Map<String, Object>> getTrendAnalysis(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        try {
            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            List<OrderItemDTO> sellerOrders = orderService.getSellerOrdersAll(userDetails.getUserId());
            
            List<Double> dailySales = sellerOrders.stream()
                    .map(order -> order.getPrice().doubleValue())
                    .collect(Collectors.toList());
            
            Map<String, Object> request = new HashMap<>();
            request.put("values", dailySales);
            request.put("window_size", 7);
            
            Map<String, Object> trend = restTemplate.postForObject(
                    PYTHON_API + "/moving-average",
                    request,
                    Map.class
            );
            
            return ResponseEntity.ok(trend);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(
                    Map.of("error", "Trend analysis service unavailable: " + e.getMessage())
            );
        }
    }

    /**
     * Volatility analysis
     */
    @GetMapping("/volatility")
    public ResponseEntity<Map<String, Object>> getVolatility(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        try {
            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            List<OrderItemDTO> sellerOrders = orderService.getSellerOrdersAll(userDetails.getUserId());
            
            List<Double> dailySales = sellerOrders.stream()
                    .map(order -> order.getPrice().doubleValue())
                    .collect(Collectors.toList());
            
            Map<String, Object> request = new HashMap<>();
            request.put("values", dailySales);
            
            Map<String, Object> volatility = restTemplate.postForObject(
                    PYTHON_API + "/volatility",
                    request,
                    Map.class
            );
            
            return ResponseEntity.ok(volatility);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(
                    Map.of("error", "Volatility analysis unavailable: " + e.getMessage())
            );
        }
    }

    /**
     * Anomaly detection
     */
    @GetMapping("/anomalies")
    public ResponseEntity<Map<String, Object>> detectAnomalies(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        try {
            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            List<OrderItemDTO> sellerOrders = orderService.getSellerOrdersAll(userDetails.getUserId());
            
            List<Double> dailySales = sellerOrders.stream()
                    .map(order -> order.getPrice().doubleValue())
                    .collect(Collectors.toList());
            
            Map<String, Object> request = new HashMap<>();
            request.put("values", dailySales);
            request.put("threshold", 2.5);
            
            Map<String, Object> anomalies = restTemplate.postForObject(
                    PYTHON_API + "/anomalies",
                    request,
                    Map.class
            );
            
            return ResponseEntity.ok(anomalies);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(
                    Map.of("error", "Anomaly detection unavailable: " + e.getMessage())
            );
        }
    }

    /**
     * ARIMA Forecasting
     */
    @GetMapping("/arima-forecast")
    public ResponseEntity<Map<String, Object>> getARIMAForecast(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        try {
            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            List<OrderItemDTO> sellerOrders = orderService.getSellerOrdersAll(userDetails.getUserId());
            
            List<Double> dailySales = sellerOrders.stream()
                    .map(order -> order.getPrice().doubleValue())
                    .collect(Collectors.toList());
            
            Map<String, Object> request = new HashMap<>();
            request.put("values", dailySales);
            request.put("steps", 30);
            
            Map<String, Object> forecast = restTemplate.postForObject(
                    PYTHON_API + "/arima-forecast",
                    request,
                    Map.class
            );
            
            return ResponseEntity.ok(forecast);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(
                    Map.of("error", "ARIMA forecast unavailable: " + e.getMessage())
            );
        }
    }

    /**
     * Correlation analysis
     */
    @GetMapping("/correlation")
    public ResponseEntity<Map<String, Object>> getCorrelation(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        try {
            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            List<OrderItemDTO> sellerOrders = orderService.getSellerOrdersAll(userDetails.getUserId());
            
            List<Double> dailySales = sellerOrders.stream()
                    .map(order -> order.getPrice().doubleValue())
                    .collect(Collectors.toList());
            
            List<Long> dailyOrders = sellerOrders.stream()
                    .map(order -> 1L)
                    .collect(Collectors.toList());
            
            Map<String, Object> request = new HashMap<>();
            request.put("revenue", dailySales);
            request.put("orders", dailyOrders.stream().mapToDouble(Long::doubleValue).boxed().collect(Collectors.toList()));
            
            Map<String, Object> correlation = restTemplate.postForObject(
                    PYTHON_API + "/correlation",
                    request,
                    Map.class
            );
            
            return ResponseEntity.ok(correlation);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(
                    Map.of("error", "Correlation analysis unavailable: " + e.getMessage())
            );
        }
    }
}
