package com.littlebloom.controller;

import com.littlebloom.dto.OrderDTO;
import com.littlebloom.dto.OrderItemDTO;
import com.littlebloom.dto.UpdateOrderStatusRequest;
import com.littlebloom.security.CustomUserDetails;
import com.littlebloom.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
@CrossOrigin(origins = "http://localhost:3000")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping
    public ResponseEntity<OrderDTO> createOrder(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        OrderDTO order = orderService.createOrder(userDetails.getUserId());
        return ResponseEntity.ok(order);
    }

    @GetMapping
    public ResponseEntity<Page<OrderDTO>> getBuyerOrders(
            Authentication authentication,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        Pageable pageable = PageRequest.of(page, size);
        Page<OrderDTO> orders = orderService.getBuyerOrders(userDetails.getUserId(), pageable);
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/all")
    public ResponseEntity<List<OrderDTO>> getBuyerOrdersAll(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        List<OrderDTO> orders = orderService.getBuyerOrdersAll(userDetails.getUserId());
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/{id}")
    public ResponseEntity<OrderDTO> getOrderById(@PathVariable Long id) {
        OrderDTO order = orderService.getOrderById(id);
        return ResponseEntity.ok(order);
    }

    @GetMapping("/seller/all")
    public ResponseEntity<List<OrderItemDTO>> getSellerOrdersAll(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        List<OrderItemDTO> orders = orderService.getSellerOrdersAll(userDetails.getUserId());
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/seller/paginated")
    public ResponseEntity<Page<OrderItemDTO>> getSellerOrdersPaginated(
            Authentication authentication,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        Pageable pageable = PageRequest.of(page, size);
        Page<OrderItemDTO> orders = orderService.getSellerOrders(userDetails.getUserId(), pageable);
        return ResponseEntity.ok(orders);
    }

    @PutMapping("/item/{itemId}/status")
    public ResponseEntity<Void> updateOrderItemStatus(
            Authentication authentication,
            @PathVariable Long itemId,
            @RequestBody UpdateOrderStatusRequest request) {
        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        orderService.updateOrderItemStatus(itemId, request.getStatus());
        return ResponseEntity.noContent().build();
    }
}
