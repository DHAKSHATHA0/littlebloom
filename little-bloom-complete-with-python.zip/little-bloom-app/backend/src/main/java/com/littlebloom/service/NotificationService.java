package com.littlebloom.service;

import com.littlebloom.dto.AddToWishlistRequest;
import com.littlebloom.dto.NotificationDTO;
import com.littlebloom.dto.WishlistDTO;
import com.littlebloom.model.*;
import com.littlebloom.repository.NotificationRepository;
import com.littlebloom.repository.ProductRepository;
import com.littlebloom.repository.UserRepository;
import com.littlebloom.repository.WishlistRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private WishlistRepository wishlistRepository;

    public void notifySellerOrderPlaced(User buyer, User seller, Product product, Integer quantity) {
        String message = buyer.getName() + " ordered " + quantity + " " + product.getName();
        Notification notification = Notification.builder()
                .sender(buyer)
                .receiver(seller)
                .message(message)
                .type(Notification.NotificationType.ORDER_PLACED)
                .isRead(false)
                .build();
        notificationRepository.save(notification);
    }

    public void notifyBuyerOrderShipped(Order order) {
        String message = "Your order #" + order.getId() + " has been shipped and is out for delivery";
        Notification notification = Notification.builder()
                .receiver(order.getBuyer())
                .message(message)
                .type(Notification.NotificationType.ORDER_SHIPPED)
                .isRead(false)
                .build();
        notificationRepository.save(notification);
    }

    public void notifyBuyerOrderDelivered(Order order) {
        String message = "Your order #" + order.getId() + " has been delivered";
        Notification notification = Notification.builder()
                .receiver(order.getBuyer())
                .message(message)
                .type(Notification.NotificationType.ORDER_DELIVERED)
                .isRead(false)
                .build();
        notificationRepository.save(notification);
    }

    public void notifySellerAboutReview(User buyer, User seller, Product product, Integer rating) {
        String message = buyer.getName() + " left a " + rating + "-star review on " + product.getName();
        Notification notification = Notification.builder()
                .sender(buyer)
                .receiver(seller)
                .message(message)
                .type(Notification.NotificationType.REVIEW_ADDED)
                .isRead(false)
                .build();
        notificationRepository.save(notification);
    }

    public List<NotificationDTO> getUserNotifications(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return notificationRepository.findByReceiverOrderByCreatedAtDesc(user).stream()
                .map(this::getNotificationDTO)
                .collect(Collectors.toList());
    }

    public List<NotificationDTO> getUnreadNotifications(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return notificationRepository.findByReceiverAndIsReadFalse(user).stream()
                .map(this::getNotificationDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public void markNotificationAsRead(Long notificationId) {
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new RuntimeException("Notification not found"));
        notification.setIsRead(true);
        notificationRepository.save(notification);
    }

    private NotificationDTO getNotificationDTO(Notification notification) {
        return NotificationDTO.builder()
                .id(notification.getId())
                .senderId(notification.getSender() != null ? notification.getSender().getId() : null)
                .senderName(notification.getSender() != null ? notification.getSender().getName() : "System")
                .receiverId(notification.getReceiver().getId())
                .message(notification.getMessage())
                .type(notification.getType().toString())
                .isRead(notification.getIsRead())
                .createdAt(notification.getCreatedAt())
                .build();
    }
}

@Service
@Slf4j
class WishlistService {

    @Autowired
    private WishlistRepository wishlistRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    @Transactional
    public WishlistDTO addToWishlist(Long userId, AddToWishlistRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Product product = productRepository.findById(request.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        if (wishlistRepository.existsByUserAndProduct(user, product)) {
            throw new RuntimeException("Product already in wishlist");
        }

        Wishlist wishlist = Wishlist.builder()
                .user(user)
                .product(product)
                .build();

        wishlist = wishlistRepository.save(wishlist);
        return getWishlistDTO(wishlist);
    }

    @Transactional
    public void removeFromWishlist(Long userId, Long productId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        Wishlist wishlist = wishlistRepository.findByUserAndProduct(user, product)
                .orElseThrow(() -> new RuntimeException("Item not in wishlist"));

        wishlistRepository.delete(wishlist);
    }

    public List<WishlistDTO> getUserWishlist(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return wishlistRepository.findByUser(user).stream()
                .map(this::getWishlistDTO)
                .collect(Collectors.toList());
    }

    public boolean isInWishlist(Long userId, Long productId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        return wishlistRepository.existsByUserAndProduct(user, product);
    }

    private WishlistDTO getWishlistDTO(Wishlist wishlist) {
        return WishlistDTO.builder()
                .id(wishlist.getId())
                .userId(wishlist.getUser().getId())
                .productId(wishlist.getProduct().getId())
                .productName(wishlist.getProduct().getName())
                .category(wishlist.getProduct().getCategory())
                .imageUrl(wishlist.getProduct().getImageUrl())
                .createdAt(wishlist.getCreatedAt())
                .build();
    }
}
