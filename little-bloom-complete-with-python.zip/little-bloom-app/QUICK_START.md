# Quick Start Guide - Little Bloom

## 🚀 Fast Track Setup (5 minutes)

### Step 1: Clone/Extract Project
```bash
cd little-bloom-app
```

### Step 2: Database Setup
```bash
# Start PostgreSQL (or use existing instance)
psql -U postgres
CREATE DATABASE littlebloom;
\q

# Load schema
psql -U postgres -d littlebloom -f database-schema.sql
```

### Step 3: Backend Setup & Run
```bash
cd backend

# Edit application.properties with your DB credentials
# spring.datasource.password=your_postgres_password

mvn clean install
mvn spring-boot:run

# Wait for: "Application 'Little Bloom Backend' started successfully"
```

### Step 4: Frontend Setup & Run (New Terminal)
```bash
cd frontend
npm install
npm start

# Wait for browser to open at http://localhost:3000
```

### Step 5: Test the App
1. Go to http://localhost:3000
2. Click "Sign Up"
3. Create a seller account (role: SELLER)
4. Add some products
5. Create a buyer account (role: BUYER)
6. Browse and purchase

---

## 📋 Default Test Credentials

### Pre-created Sellers (after DB schema loaded):
- Email: seller1@littlebloom.com
- Password: seller123

### Pre-created Buyers (after DB schema loaded):
- Email: buyer1@littlebloom.com
- Password: buyer123

---

## 🐛 Common Issues & Fixes

### PostgreSQL Connection Failed
```bash
# Check PostgreSQL is running
psql -U postgres

# If not found, install:
# macOS: brew install postgresql
# Ubuntu: sudo apt-get install postgresql
# Windows: Download from postgresql.org
```

### Port 8080 Already in Use
```bash
# Kill process using port 8080
lsof -ti:8080 | xargs kill -9

# Or use different port in application.properties
server.port=8081
```

### NPM Dependencies Issue
```bash
rm -rf node_modules package-lock.json
npm install
```

### Maven Build Fails
```bash
mvn clean
mvn install -U
```

---

## 📊 Architecture Overview

```
Client (React)
    ↓ (HTTP/REST with JWT)
API Gateway (Spring Security)
    ↓
Spring Boot Services
    ↓
JPA/Hibernate ORM
    ↓
PostgreSQL Database
```

---

## 📱 API Endpoints Quick Reference

### Auth
- `POST /api/auth/signup` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user

### Products
- `GET /api/products` - List all products
- `GET /api/products/search?search=term` - Search
- `POST /api/products` - Create product (Seller)
- `DELETE /api/products/{id}` - Delete product (Seller)

### Cart
- `POST /api/cart/add` - Add to cart
- `GET /api/cart` - Get cart
- `DELETE /api/cart/remove/{productId}` - Remove item

### Orders
- `POST /api/orders` - Create order
- `GET /api/orders` - Get buyer orders
- `GET /api/orders/seller/all` - Get seller orders
- `PUT /api/orders/item/{itemId}/status` - Update status

### Reviews
- `POST /api/reviews` - Create review
- `GET /api/reviews/product/{id}` - Get product reviews

---

## 🎯 Next Steps After Setup

1. **Explore Buyer Portal**
   - Home page with search
   - Browse products by category
   - Add items to cart
   - Place order

2. **Explore Seller Portal**
   - Add new products
   - View orders
   - Update order status
   - Check sales analytics

3. **Review System**
   - Complete an order
   - Leave a review (post-delivery only)
   - Check average ratings

4. **Notifications**
   - Monitor real-time notifications
   - See order updates
   - Receive review alerts

---

## 📝 Production Checklist

Before deploying to production:

- [ ] Change JWT secret in `application.properties`
- [ ] Update database credentials
- [ ] Set CORS origins to production domain
- [ ] Enable HTTPS
- [ ] Set up environment variables
- [ ] Configure file upload location
- [ ] Set up CDN for product images
- [ ] Configure email notifications
- [ ] Set up monitoring & logging
- [ ] Test all user flows
- [ ] Load testing
- [ ] Security audit

---

## 📞 Support Resources

### Logs Location
- **Backend**: Console output + `logs/` directory
- **Frontend**: Browser DevTools Console (F12)

### Check Services Status
```bash
# Backend health
curl http://localhost:8080/api/auth/health

# Frontend
Open http://localhost:3000

# Database
psql -U postgres -d littlebloom -c "SELECT 1"
```

---

## 🔄 Development Workflow

### When Modifying Backend
1. Make code changes
2. Backend auto-reloads (DevTools enabled)
3. Restart if needed: Ctrl+C, then `mvn spring-boot:run`

### When Modifying Frontend
1. Make code changes
2. React auto-reloads
3. Check browser for errors

---

## 📦 Project Structure Summary

```
little-bloom-app/
├── README.md                 # Full documentation
├── QUICK_START.md           # This file
├── database-schema.sql      # PostgreSQL schema
├── docker-compose.yml       # Docker setup (optional)
├── backend/                 # Spring Boot application
│   ├── pom.xml
│   ├── src/
│   └── target/             # Build output
└── frontend/                # React application
    ├── package.json
    ├── src/
    └── public/
```

---

## ✅ Verify Everything Works

Run this test:

1. **Backend Ready**
```bash
curl -X GET http://localhost:8080/api/auth/health
# Should return: "Backend is running"
```

2. **Frontend Ready**
```
Open http://localhost:3000
# Should show login/signup page
```

3. **Database Ready**
```bash
psql -U postgres -d littlebloom -c "\dt"
# Should show all tables
```

If all three work, you're ready! 🎉

---

**Last Updated**: March 31, 2026
**Version**: 1.0.0
