// frontend/src/components/Header.js
import React, { useContext, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { notificationAPI } from '../services/api';

export default function Header() {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [showDropdown, setShowDropdown] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);

  React.useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 30000);
    return () => clearInterval(interval);
  }, []);

  const fetchNotifications = async () => {
    try {
      const response = await notificationAPI.getUnreadNotifications();
      setNotifications(response.data);
    } catch (error) {
      console.error('Failed to fetch notifications:', error);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const isSeller = user?.role === 'SELLER';

  return (
    <header className="bg-white shadow-md sticky top-0 z-40">
      <nav className="container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center">
            <span className="text-white text-lg font-bold">🌸</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-800">Little Bloom</h1>
        </Link>

        {/* Navigation */}
        <div className="flex items-center gap-6">
          {isSeller ? (
            <>
              <Link to="/seller/dashboard" className="text-gray-700 hover:text-pink-600 font-medium">
                Dashboard
              </Link>
              <Link to="/seller/products" className="text-gray-700 hover:text-pink-600 font-medium">
                Products
              </Link>
              <Link to="/seller/orders" className="text-gray-700 hover:text-pink-600 font-medium">
                Orders
              </Link>
            </>
          ) : (
            <>
              <Link to="/" className="text-gray-700 hover:text-pink-600 font-medium">
                Home
              </Link>
              <Link to="/menu" className="text-gray-700 hover:text-pink-600 font-medium">
                Shop
              </Link>
              <Link to="/cart" className="text-gray-700 hover:text-pink-600 font-medium">
                Cart
              </Link>
              <Link to="/orders" className="text-gray-700 hover:text-pink-600 font-medium">
                Orders
              </Link>
            </>
          )}

          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative text-gray-700 hover:text-pink-600"
            >
              🔔
              {notifications.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {notifications.length}
                </span>
              )}
            </button>
            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg max-h-96 overflow-y-auto">
                {notifications.length > 0 ? (
                  notifications.map((notif) => (
                    <div key={notif.id} className="p-4 border-b hover:bg-gray-50">
                      <p className="text-sm text-gray-800">{notif.message}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(notif.createdAt).toLocaleString()}
                      </p>
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-center text-gray-500">
                    No notifications
                  </div>
                )}
              </div>
            )}
          </div>

          {/* User Menu */}
          <div className="relative">
            <button
              onClick={() => setShowDropdown(!showDropdown)}
              className="flex items-center gap-2 px-4 py-2 bg-pink-50 rounded-lg hover:bg-pink-100"
            >
              <span className="text-lg">👤</span>
              <span className="text-gray-800">{user?.name}</span>
            </button>
            {showDropdown && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg overflow-hidden">
                <Link
                  to="/profile"
                  className="block px-4 py-2 text-gray-800 hover:bg-gray-100"
                >
                  My Profile
                </Link>
                <button
                  onClick={handleLogout}
                  className="w-full text-left px-4 py-2 text-red-600 hover:bg-red-50"
                >
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </nav>
    </header>
  );
}
