// frontend/src/components/Footer.js
import React from 'react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white mt-16">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <span className="text-2xl">🌸</span>
              Little Bloom
            </h3>
            <p className="text-gray-400 text-sm">
              Your trusted platform for premium baby products. Quality, safety, and affordability in one place.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li><a href="/" className="hover:text-white">Home</a></li>
              <li><a href="/menu" className="hover:text-white">Shop</a></li>
              <li><a href="/orders" className="hover:text-white">Orders</a></li>
              <li><a href="/profile" className="hover:text-white">Profile</a></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-lg font-bold mb-4">Categories</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li><a href="/menu" className="hover:text-white">Dresses</a></li>
              <li><a href="/menu" className="hover:text-white">Footwear</a></li>
              <li><a href="/menu" className="hover:text-white">Toys</a></li>
              <li><a href="/menu" className="hover:text-white">Accessories</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-bold mb-4">Contact</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li>Email: support@littlebloom.com</li>
              <li>Phone: +91 98765 43210</li>
              <li>Address: Mumbai, India</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              &copy; {currentYear} Little Bloom. All rights reserved.
            </p>
            <div className="flex gap-4 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-white">Terms of Service</a>
              <a href="#" className="text-gray-400 hover:text-white">Contact Us</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

// frontend/src/components/Loading.js
import React from 'react';

export default function Loading() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="text-center">
        <div className="inline-block animate-spin">
          <svg
            className="w-12 h-12 text-pink-500"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            />
          </svg>
        </div>
        <p className="mt-4 text-gray-600 text-lg">Loading...</p>
      </div>
    </div>
  );
}

// frontend/src/components/ProductCard.js
import React from 'react';
import { Link } from 'react-router-dom';

export default function ProductCard({ product }) {
  const renderStars = (rating) => {
    return (
      <div className="flex items-center gap-1">
        {[...Array(5)].map((_, i) => (
          <span key={i} className={i < Math.round(rating) ? '⭐' : '☆'}>
            {i < Math.round(rating) ? '⭐' : '☆'}
          </span>
        ))}
        <span className="text-xs text-gray-600">({product.reviewCount || 0})</span>
      </div>
    );
  };

  return (
    <Link to={`/product/${product.id}`}>
      <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
        {/* Image */}
        <div className="relative h-48 bg-gray-200 overflow-hidden">
          {product.imageUrl ? (
            <img
              src={product.imageUrl}
              alt={product.name}
              className="w-full h-full object-cover hover:scale-105 transition-transform"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gray-300">
              <span className="text-4xl">👶</span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4">
          <h3 className="text-lg font-semibold text-gray-800 truncate">
            {product.name}
          </h3>
          <p className="text-sm text-gray-600 mt-1 truncate">
            {product.category}
          </p>
          <p className="text-sm text-gray-600 mt-1 line-clamp-2">
            {product.description}
          </p>

          {/* Rating */}
          <div className="mt-2">
            {renderStars(product.avgRating || 0)}
          </div>

          {/* Price and Stock */}
          <div className="mt-4 flex items-center justify-between">
            <span className="text-2xl font-bold text-pink-600">
              ₹{product.price}
            </span>
            <span className={`text-sm font-semibold ${
              product.quantity > 0 ? 'text-green-600' : 'text-red-600'
            }`}>
              {product.quantity > 0 ? `In Stock` : 'Out of Stock'}
            </span>
          </div>

          {/* Delivery */}
          <p className="text-xs text-gray-500 mt-2">
            📦 Delivery in {product.predictedDeliveryDays} days
          </p>
        </div>
      </div>
    </Link>
  );
}
