// frontend/src/pages/SellerDashboard.js
import React, { useState, useEffect } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { toast } from 'react-toastify';
import axios from 'axios';

const API_URL = 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default function SellerDashboard() {
  const [dashboard, setDashboard] = useState(null);
  const [prediction, setPrediction] = useState(null);
  const [trendAnalysis, setTrendAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const [dashboardRes, predictionRes, trendRes] = await Promise.all([
        api.get('/analytics/dashboard'),
        api.get('/analytics/prediction/next-month'),
        api.get('/analytics/trend-analysis?windowSize=7'),
      ]);

      setDashboard(dashboardRes.data);
      setPrediction(predictionRes.data);
      setTrendAnalysis(trendRes.data);
    } catch (error) {
      toast.error('Failed to load analytics');
      console.error('Analytics error:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin inline-block">
            <svg className="w-12 h-12 text-pink-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
          </div>
          <p className="mt-4 text-gray-600">Loading analytics...</p>
        </div>
      </div>
    );
  }

  if (!dashboard) {
    return (
      <div className="text-center py-12">
        <p className="text-xl text-gray-600">No data available</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8 text-gray-800">📊 Seller Dashboard</h1>

      {/* Quick Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {/* This Month Stats */}
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-6 shadow">
          <h3 className="text-sm font-semibold text-blue-600 uppercase mb-2">This Month Revenue</h3>
          <p className="text-3xl font-bold text-blue-900">₹{dashboard.thisMonth?.totalRevenue?.toLocaleString()}</p>
          <p className="text-sm text-blue-600 mt-2">{dashboard.thisMonth?.totalOrders} orders</p>
        </div>

        {/* Last 30 Days Stats */}
        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-6 shadow">
          <h3 className="text-sm font-semibold text-green-600 uppercase mb-2">Last 30 Days</h3>
          <p className="text-3xl font-bold text-green-900">₹{dashboard.last30Days?.totalRevenue?.toLocaleString()}</p>
          <p className="text-sm text-green-600 mt-2">{dashboard.last30Days?.totalOrders} orders</p>
        </div>

        {/* Average Order Value */}
        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-6 shadow">
          <h3 className="text-sm font-semibold text-purple-600 uppercase mb-2">Avg Order Value</h3>
          <p className="text-3xl font-bold text-purple-900">
            ₹{Math.round(dashboard.thisMonth?.averageOrderValue || 0)}
          </p>
          <p className="text-sm text-purple-600 mt-2">This month</p>
        </div>

        {/* Items Sold */}
        <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg p-6 shadow">
          <h3 className="text-sm font-semibold text-orange-600 uppercase mb-2">Items Sold</h3>
          <p className="text-3xl font-bold text-orange-900">{dashboard.thisMonth?.totalItems}</p>
          <p className="text-sm text-orange-600 mt-2">This month</p>
        </div>
      </div>

      {/* Prediction Card - DATA SCIENCE */}
      {prediction && (
        <div className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-lg p-8 mb-8 border-2 border-pink-200 shadow-lg">
          <div className="flex items-center gap-2 mb-4">
            <span className="text-3xl">🤖</span>
            <h2 className="text-2xl font-bold text-gray-800">AI Sales Prediction</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Predicted Revenue */}
            <div className="bg-white rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-2">Predicted Next Month Revenue</p>
              <p className="text-2xl font-bold text-pink-600">
                ₹{Math.round(prediction.predictedRevenue || 0)}
              </p>
              <p className="text-xs text-gray-500 mt-2">Based on linear regression</p>
            </div>

            {/* Predicted Orders */}
            <div className="bg-white rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-2">Predicted Orders</p>
              <p className="text-2xl font-bold text-blue-600">{prediction.predictedOrders}</p>
              <p className="text-xs text-gray-500 mt-2">Expected number</p>
            </div>

            {/* Confidence Score */}
            <div className="bg-white rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-2">Model Confidence</p>
              <div className="flex items-center gap-2">
                <p className="text-2xl font-bold text-purple-600">{(prediction.confidence || 0).toFixed(1)}%</p>
                <div className="w-16 bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-purple-600 h-2 rounded-full" 
                    style={{ width: `${Math.min(prediction.confidence || 0, 100)}%` }}
                  />
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-2">R² value (accuracy)</p>
            </div>

            {/* Trend */}
            <div className="bg-white rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-2">Sales Trend</p>
              <p className="text-2xl font-bold">{prediction.trend}</p>
              <p className="text-xs text-gray-500 mt-2">
                {Math.abs(prediction.slope || 0).toFixed(2)} ₹/day change
              </p>
            </div>
          </div>

          {/* Prediction Details */}
          <div className="mt-6 p-4 bg-white rounded-lg border-l-4 border-pink-500">
            <p className="text-sm font-semibold text-gray-700 mb-2">📈 How It Works</p>
            <p className="text-xs text-gray-600">
              This prediction uses <strong>Linear Regression</strong> analysis on your last 30 days of sales data. 
              The model analyzes daily revenue trends and projects forward to estimate next month's performance. 
              Higher confidence scores indicate more reliable predictions.
            </p>
          </div>
        </div>
      )}

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Weekly Sales Chart */}
        {dashboard?.weeklyChart && (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-xl font-bold mb-4 text-gray-800">📅 Weekly Sales</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={dashboard.weeklyChart}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" angle={-45} textAnchor="end" height={80} />
                <YAxis />
                <Tooltip formatter={(value) => `₹${value.toFixed(0)}`} />
                <Legend />
                <Bar dataKey="revenue" fill="#EC4899" name="Revenue" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Monthly Sales Chart */}
        {dashboard?.monthlyChart && (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-xl font-bold mb-4 text-gray-800">📊 Monthly Sales</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={dashboard.monthlyChart}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" angle={-45} textAnchor="end" height={80} />
                <YAxis />
                <Tooltip formatter={(value) => `₹${value.toFixed(0)}`} />
                <Legend />
                <Line type="monotone" dataKey="revenue" stroke="#3B82F6" strokeWidth={2} name="Revenue" />
                <Line type="monotone" dataKey="orders" stroke="#10B981" strokeWidth={2} name="Orders" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Trend Analysis - DATA SCIENCE */}
      {trendAnalysis && (
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h3 className="text-xl font-bold mb-4 text-gray-800">📈 Trend Analysis (Moving Average)</h3>
          <p className="text-sm text-gray-600 mb-4">
            Shows actual daily revenue (blue), 7-day moving average (green), and volatility indicator (orange)
          </p>
          <ResponsiveContainer width="100%" height={350}>
            <LineChart data={trendAnalysis}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" angle={-45} textAnchor="end" height={80} />
              <YAxis />
              <Tooltip formatter={(value) => `₹${value.toFixed(0)}`} />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="actualRevenue" 
                stroke="#3B82F6" 
                strokeWidth={1}
                name="Actual Revenue"
                dot={false}
              />
              <Line 
                type="monotone" 
                dataKey="movingAverage" 
                stroke="#10B981" 
                strokeWidth={2}
                name="7-Day Moving Avg"
                dot={false}
              />
              <Line 
                type="monotone" 
                dataKey="volatility" 
                stroke="#F97316" 
                strokeWidth={1}
                name="Volatility (Std Dev)"
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
          <p className="text-xs text-gray-600 mt-4">
            <strong>Moving Average:</strong> Smoothed trend showing overall direction without daily fluctuations | 
            <strong> Volatility:</strong> Shows revenue variation/risk level
          </p>
        </div>
      )}

      {/* Recent Orders Summary */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-xl font-bold mb-4 text-gray-800">📦 Quick Stats</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-xs text-gray-600 mb-1">Total Revenue (30 days)</p>
            <p className="text-2xl font-bold text-gray-800">
              ₹{dashboard.last30Days?.totalRevenue?.toLocaleString()}
            </p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-xs text-gray-600 mb-1">Total Orders (30 days)</p>
            <p className="text-2xl font-bold text-gray-800">{dashboard.last30Days?.totalOrders}</p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-xs text-gray-600 mb-1">Avg Monthly Revenue</p>
            <p className="text-2xl font-bold text-gray-800">
              ₹{Math.round((dashboard.last30Days?.totalRevenue || 0) / 30)}
            </p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-xs text-gray-600 mb-1">Items Sold (30 days)</p>
            <p className="text-2xl font-bold text-gray-800">{dashboard.last30Days?.totalItems}</p>
          </div>
        </div>
      </div>

      {/* Data Science Explanation */}
      <div className="mt-8 p-6 bg-blue-50 rounded-lg border-l-4 border-blue-500">
        <h3 className="text-lg font-bold text-blue-900 mb-3">🧠 Data Science Features Explained</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
          <div>
            <h4 className="font-semibold text-blue-900 mb-2">📊 Linear Regression Prediction</h4>
            <p className="text-blue-800">
              Analyzes historical sales data to predict future trends. The confidence score (R²) indicates how well the model fits your actual data.
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-blue-900 mb-2">📈 Moving Average Trend</h4>
            <p className="text-blue-800">
              Smooths daily fluctuations to show the true underlying trend. Volatility measures how much your sales vary day-to-day.
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-blue-900 mb-2">🎯 Growth Rate Analysis</h4>
            <p className="text-blue-800">
              Shows the slope (rate of change) in your sales. Positive slope = growth, negative = decline. Use this to optimize inventory.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
