#!/bin/bash

# Little Bloom - Analytics Server Setup
# Installs Python dependencies and starts data science server

echo "=========================================="
echo "  Little Bloom - Analytics Server Setup"
echo "=========================================="
echo ""

# Check Python installation
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed"
    echo "Download from: https://www.python.org/downloads/"
    exit 1
fi

echo "✅ Python 3 found: $(python3 --version)"
echo ""

# Create virtual environment
echo "📦 Creating virtual environment..."
python3 -m venv venv

# Activate virtual environment
echo "🔌 Activating virtual environment..."
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
echo "📥 Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo ""
echo "=========================================="
echo "  ✅ Setup Complete!"
echo "=========================================="
echo ""
echo "To start the analytics server, run:"
echo ""
echo "  source venv/bin/activate  # On Windows: venv\Scripts\activate"
echo "  python app.py"
echo ""
echo "Server will run on: http://localhost:5000"
echo ""
echo "Health check: curl http://localhost:5000/health"
echo ""
