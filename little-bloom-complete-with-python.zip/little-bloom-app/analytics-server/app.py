#!/usr/bin/env python3
"""
Little Bloom - Data Science Analytics Server
Python Flask API for sales prediction and analytics
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

app = Flask(__name__)
CORS(app)

# ==============================================================================
# DATA SCIENCE FUNCTIONS
# ==============================================================================

class SalesAnalytics:
    """Data Science Analytics using NumPy, Pandas, scikit-learn"""
    
    @staticmethod
    def linear_regression_forecast(daily_sales_data):
        """
        Linear Regression for sales prediction
        
        Args:
            daily_sales_data: List of daily revenue values
            
        Returns:
            dict with prediction, confidence (R²), slope, intercept
        """
        if not daily_sales_data or len(daily_sales_data) < 2:
            return {
                'predicted_revenue': 0,
                'predicted_orders': 0,
                'confidence': 0,
                'trend': 'Insufficient data',
                'slope': 0,
                'intercept': 0,
                'r_squared': 0
            }
        
        # Prepare data
        X = np.array(range(len(daily_sales_data))).reshape(-1, 1)
        y = np.array(daily_sales_data)
        
        # Linear Regression
        model = LinearRegression()
        model.fit(X, y)
        
        # Predictions
        slope = float(model.coef_[0])
        intercept = float(model.intercept_)
        next_day_prediction = float(model.predict([[len(daily_sales_data)]])[0])
        
        # R² Score (confidence)
        r_squared = float(model.score(X, y))
        confidence = max(0, min(100, r_squared * 100))
        
        # Trend
        if slope > 500:
            trend = "📈 Strong Growth"
        elif slope > 0:
            trend = "📈 Slight Growth"
        elif slope > -500:
            trend = "📉 Slight Decline"
        else:
            trend = "📉 Strong Decline"
        
        return {
            'predicted_revenue': round(next_day_prediction, 2),
            'predicted_orders': max(0, int(next_day_prediction / 2000)),  # Estimate
            'confidence': round(confidence, 2),
            'trend': trend,
            'slope': round(slope, 2),
            'intercept': round(intercept, 2),
            'r_squared': round(r_squared, 4)
        }
    
    @staticmethod
    def moving_average(data, window_size=7):
        """
        Moving Average for trend analysis
        
        Args:
            data: List of values
            window_size: Size of moving window
            
        Returns:
            List of moving averages
        """
        df = pd.DataFrame({'value': data})
        df['moving_avg'] = df['value'].rolling(window=window_size).mean()
        return df['moving_avg'].fillna(df['value']).tolist()
    
    @staticmethod
    def calculate_volatility(data):
        """
        Standard Deviation - Volatility measurement
        
        Args:
            data: List of values
            
        Returns:
            Standard deviation
        """
        return float(np.std(data))
    
    @staticmethod
    def exponential_smoothing(data, alpha=0.3):
        """
        Exponential Smoothing for trend
        
        Args:
            data: List of values
            alpha: Smoothing factor (0-1)
            
        Returns:
            List of smoothed values
        """
        result = [data[0]]
        for i in range(1, len(data)):
            smoothed = alpha * data[i] + (1 - alpha) * result[-1]
            result.append(smoothed)
        return result
    
    @staticmethod
    def seasonal_decomposition(data, period=7):
        """
        Time Series Decomposition
        
        Args:
            data: List of values
            period: Seasonal period
            
        Returns:
            dict with trend, seasonal, residual
        """
        try:
            from statsmodels.tsa.seasonal import seasonal_decompose
            
            ts = pd.Series(data)
            decomposition = seasonal_decompose(ts, model='additive', period=period, extrapolate='fill_even')
            
            return {
                'trend': decomposition.trend.tolist(),
                'seasonal': decomposition.seasonal.tolist(),
                'residual': decomposition.resid.tolist()
            }
        except:
            return {
                'trend': data,
                'seasonal': [0] * len(data),
                'residual': [0] * len(data)
            }
    
    @staticmethod
    def arima_forecast(data, steps=1):
        """
        ARIMA Forecasting (if available)
        
        Args:
            data: List of historical values
            steps: Number of steps to forecast
            
        Returns:
            Forecasted values
        """
        try:
            from statsmodels.tsa.arima.model import ARIMA
            
            model = ARIMA(data, order=(1, 1, 1))
            fitted_model = model.fit()
            forecast = fitted_model.forecast(steps=steps)
            return [float(x) for x in forecast]
        except:
            # Fallback to simple average
            return [np.mean(data)] * steps
    
    @staticmethod
    def detect_anomalies(data, threshold=2.5):
        """
        Anomaly Detection using Standard Deviation
        
        Args:
            data: List of values
            threshold: Standard deviations from mean
            
        Returns:
            List of anomaly indices
        """
        mean = np.mean(data)
        std = np.std(data)
        
        anomalies = []
        for i, value in enumerate(data):
            if abs(value - mean) > threshold * std:
                anomalies.append(i)
        
        return anomalies
    
    @staticmethod
    def correlation_analysis(revenue_data, order_data):
        """
        Correlation between revenue and orders
        
        Args:
            revenue_data: List of daily revenue
            order_data: List of daily orders
            
        Returns:
            Correlation coefficient
        """
        return float(np.corrcoef(revenue_data, order_data)[0, 1])

# ==============================================================================
# API ENDPOINTS
# ==============================================================================

@app.route('/api/analytics/predict', methods=['POST'])
def predict_sales():
    """Predict next month sales using Linear Regression"""
    try:
        data = request.get_json()
        daily_sales = data.get('daily_sales', [])
        
        prediction = SalesAnalytics.linear_regression_forecast(daily_sales)
        return jsonify(prediction), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/analytics/moving-average', methods=['POST'])
def get_moving_average():
    """Get moving average for trend analysis"""
    try:
        data = request.get_json()
        values = data.get('values', [])
        window = data.get('window_size', 7)
        
        ma = SalesAnalytics.moving_average(values, window)
        return jsonify({'moving_average': ma}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/analytics/volatility', methods=['POST'])
def get_volatility():
    """Calculate volatility (standard deviation)"""
    try:
        data = request.get_json()
        values = data.get('values', [])
        
        volatility = SalesAnalytics.calculate_volatility(values)
        return jsonify({'volatility': volatility}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/analytics/exponential-smoothing', methods=['POST'])
def get_exponential_smoothing():
    """Get exponentially smoothed data"""
    try:
        data = request.get_json()
        values = data.get('values', [])
        alpha = data.get('alpha', 0.3)
        
        smoothed = SalesAnalytics.exponential_smoothing(values, alpha)
        return jsonify({'smoothed': smoothed}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/analytics/decomposition', methods=['POST'])
def get_decomposition():
    """Time Series Decomposition"""
    try:
        data = request.get_json()
        values = data.get('values', [])
        period = data.get('period', 7)
        
        decomp = SalesAnalytics.seasonal_decomposition(values, period)
        return jsonify(decomp), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/analytics/arima-forecast', methods=['POST'])
def get_arima_forecast():
    """ARIMA Forecasting"""
    try:
        data = request.get_json()
        values = data.get('values', [])
        steps = data.get('steps', 30)
        
        forecast = SalesAnalytics.arima_forecast(values, steps)
        return jsonify({'forecast': forecast}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/analytics/anomalies', methods=['POST'])
def detect_anomalies():
    """Detect anomalies in data"""
    try:
        data = request.get_json()
        values = data.get('values', [])
        threshold = data.get('threshold', 2.5)
        
        anomalies = SalesAnalytics.detect_anomalies(values, threshold)
        return jsonify({'anomalies': anomalies}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/analytics/correlation', methods=['POST'])
def get_correlation():
    """Calculate correlation between variables"""
    try:
        data = request.get_json()
        revenue = data.get('revenue', [])
        orders = data.get('orders', [])
        
        corr = SalesAnalytics.correlation_analysis(revenue, orders)
        return jsonify({'correlation': corr}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/analytics/dashboard', methods=['POST'])
def get_dashboard_analytics():
    """Complete dashboard analytics"""
    try:
        data = request.get_json()
        daily_sales = data.get('daily_sales', [])
        daily_orders = data.get('daily_orders', [])
        period = data.get('period', 7)
        
        # Get all analytics
        prediction = SalesAnalytics.linear_regression_forecast(daily_sales)
        ma = SalesAnalytics.moving_average(daily_sales, 7)
        volatility = SalesAnalytics.calculate_volatility(daily_sales)
        smooth = SalesAnalytics.exponential_smoothing(daily_sales)
        arima_forecast = SalesAnalytics.arima_forecast(daily_sales, 30)
        anomalies = SalesAnalytics.detect_anomalies(daily_sales)
        
        try:
            correlation = SalesAnalytics.correlation_analysis(daily_sales, daily_orders)
        except:
            correlation = 0
        
        return jsonify({
            'prediction': prediction,
            'moving_average': ma,
            'volatility': volatility,
            'exponential_smoothing': smooth,
            'arima_forecast': arima_forecast,
            'anomalies': anomalies,
            'correlation': correlation
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/health', methods=['GET'])
def health():
    """Health check"""
    return jsonify({
        'status': 'healthy',
        'service': 'Little Bloom Analytics',
        'version': '1.0.0',
        'libraries': ['NumPy', 'Pandas', 'scikit-learn', 'statsmodels']
    }), 200

# ==============================================================================
# MAIN
# ==============================================================================

if __name__ == '__main__':
    print("""
    ╔══════════════════════════════════════════════════════╗
    ║   Little Bloom - Data Science Analytics Server      ║
    ║   Python Flask API with ML/DS Features              ║
    ║   Port: 5000                                        ║
    ╚══════════════════════════════════════════════════════╝
    
    Features:
    ✓ Linear Regression (predictions)
    ✓ Moving Average (trends)
    ✓ Volatility Analysis (risk)
    ✓ Exponential Smoothing (smoothing)
    ✓ Time Series Decomposition
    ✓ ARIMA Forecasting
    ✓ Anomaly Detection
    ✓ Correlation Analysis
    
    Libraries:
    ✓ NumPy - Numerical computing
    ✓ Pandas - Data manipulation
    ✓ scikit-learn - Machine learning
    ✓ statsmodels - Statistical modeling
    
    Starting server on http://localhost:5000
    """)
    
    app.run(debug=True, port=5000, host='0.0.0.0')
